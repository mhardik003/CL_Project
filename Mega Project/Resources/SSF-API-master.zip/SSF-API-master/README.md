# SSF-API
ssfAPI which handle annotated files in SSF format
